(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [631], {
        522: function(e, t, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/[subdomain]", function() {
                return n(8329)
            }])
        },
        638: function(e, t, n) {
            "use strict";
            var r = n(6856).Z,
                a = n(337).Z;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                var n = u.default,
                    o = {
                        loading: function(e) {
                            e.error, e.isLoading;
                            return e.pastDelay, null
                        }
                    };
                r(e, Promise) ? o.loader = function() {
                    return e
                } : "function" === typeof e ? o.loader = e : "object" === typeof e && (o = a({}, o, e));
                !1;
                (o = a({}, o, t)).loadableGenerated && delete(o = a({}, o, o.loadableGenerated)).loadableGenerated;
                if ("boolean" === typeof o.ssr && !o.suspense) {
                    if (!o.ssr) return delete o.ssr, i(n, o);
                    delete o.ssr
                }
                return n(o)
            }, t.noSSR = i;
            o(n(7294));
            var u = o(n(4302));

            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function i(e, t) {
                return delete t.webpack, delete t.modules, e(t)
            }("function" === typeof t.default || "object" === typeof t.default && null !== t.default) && "undefined" === typeof t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        6319: function(e, t, n) {
            "use strict";
            var r;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.LoadableContext = void 0;
            var a = ((r = n(7294)) && r.__esModule ? r : {
                default: r
            }).default.createContext(null);
            t.LoadableContext = a
        },
        4302: function(e, t, n) {
            "use strict";
            var r = n(9658).Z,
                a = n(7222).Z,
                u = n(337).Z,
                o = n(9961).Z;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, l = (i = n(7294)) && i.__esModule ? i : {
                    default: i
                },
                s = n(6319);
            var d = n(7294).useSyncExternalStore,
                f = [],
                c = [],
                b = !1;

            function p(e) {
                var t = e(),
                    n = {
                        loading: !0,
                        loaded: null,
                        error: null
                    };
                return n.promise = t.then((function(e) {
                    return n.loading = !1, n.loaded = e, e
                })).catch((function(e) {
                    throw n.loading = !1, n.error = e, e
                })), n
            }
            var _ = function() {
                function e(t, n) {
                    r(this, e), this._loadFn = t, this._opts = n, this._callbacks = new Set, this._delay = null, this._timeout = null, this.retry()
                }
                return a(e, [{
                    key: "promise",
                    value: function() {
                        return this._res.promise
                    }
                }, {
                    key: "retry",
                    value: function() {
                        var e = this;
                        this._clearTimeouts(), this._res = this._loadFn(this._opts.loader), this._state = {
                            pastDelay: !1,
                            timedOut: !1
                        };
                        var t = this._res,
                            n = this._opts;
                        if (t.loading) {
                            if ("number" === typeof n.delay)
                                if (0 === n.delay) this._state.pastDelay = !0;
                                else {
                                    var r = this;
                                    this._delay = setTimeout((function() {
                                        r._update({
                                            pastDelay: !0
                                        })
                                    }), n.delay)
                                }
                            if ("number" === typeof n.timeout) {
                                var a = this;
                                this._timeout = setTimeout((function() {
                                    a._update({
                                        timedOut: !0
                                    })
                                }), n.timeout)
                            }
                        }
                        this._res.promise.then((function() {
                            e._update({}), e._clearTimeouts()
                        })).catch((function(t) {
                            e._update({}), e._clearTimeouts()
                        })), this._update({})
                    }
                }, {
                    key: "_update",
                    value: function(e) {
                        this._state = u(o(u({}, this._state), {
                            error: this._res.error,
                            loaded: this._res.loaded,
                            loading: this._res.loading
                        }), e), this._callbacks.forEach((function(e) {
                            return e()
                        }))
                    }
                }, {
                    key: "_clearTimeouts",
                    value: function() {
                        clearTimeout(this._delay), clearTimeout(this._timeout)
                    }
                }, {
                    key: "getCurrentValue",
                    value: function() {
                        return this._state
                    }
                }, {
                    key: "subscribe",
                    value: function(e) {
                        var t = this;
                        return this._callbacks.add(e),
                            function() {
                                t._callbacks.delete(e)
                            }
                    }
                }]), e
            }();

            function h(e) {
                return function(e, t) {
                    var n = function() {
                            if (!i) {
                                var t = new _(e, a);
                                i = {
                                    getCurrentValue: t.getCurrentValue.bind(t),
                                    subscribe: t.subscribe.bind(t),
                                    retry: t.retry.bind(t),
                                    promise: t.promise.bind(t)
                                }
                            }
                            return i.promise()
                        },
                        r = function() {
                            n();
                            var e = l.default.useContext(s.LoadableContext);
                            e && Array.isArray(a.modules) && a.modules.forEach((function(t) {
                                e(t)
                            }))
                        },
                        a = Object.assign({
                            loader: null,
                            loading: null,
                            delay: 200,
                            timeout: null,
                            webpack: null,
                            modules: null,
                            suspense: !1
                        }, t);
                    a.suspense && (a.lazy = l.default.lazy(a.loader));
                    var i = null;
                    if (!b) {
                        var f = a.webpack ? a.webpack() : a.modules;
                        f && c.push((function(e) {
                            var t = !0,
                                r = !1,
                                a = void 0;
                            try {
                                for (var u, o = f[Symbol.iterator](); !(t = (u = o.next()).done); t = !0) {
                                    var i = u.value;
                                    if (-1 !== e.indexOf(i)) return n()
                                }
                            } catch (l) {
                                r = !0, a = l
                            } finally {
                                try {
                                    t || null == o.return || o.return()
                                } finally {
                                    if (r) throw a
                                }
                            }
                        }))
                    }
                    var p = a.suspense ? function(e, t) {
                        return r(), l.default.createElement(a.lazy, o(u({}, e), {
                            ref: t
                        }))
                    } : function(e, t) {
                        r();
                        var n = d(i.subscribe, i.getCurrentValue, i.getCurrentValue);
                        return l.default.useImperativeHandle(t, (function() {
                            return {
                                retry: i.retry
                            }
                        }), []), l.default.useMemo((function() {
                            return n.loading || n.error ? l.default.createElement(a.loading, {
                                isLoading: n.loading,
                                pastDelay: n.pastDelay,
                                timedOut: n.timedOut,
                                error: n.error,
                                retry: i.retry
                            }) : n.loaded ? l.default.createElement(function(e) {
                                return e && e.__esModule ? e.default : e
                            }(n.loaded), e) : null
                        }), [e, n])
                    };
                    return p.preload = function() {
                        return n()
                    }, p.displayName = "LoadableComponent", l.default.forwardRef(p)
                }(p, e)
            }

            function y(e, t) {
                for (var n = []; e.length;) {
                    var r = e.pop();
                    n.push(r(t))
                }
                return Promise.all(n).then((function() {
                    if (e.length) return y(e, t)
                }))
            }
            h.preloadAll = function() {
                return new Promise((function(e, t) {
                    y(f).then(e, t)
                }))
            }, h.preloadReady = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                return new Promise((function(t) {
                    var n = function() {
                        return b = !0, t()
                    };
                    y(c, e).then(n, n)
                }))
            }, window.__NEXT_PRELOADREADY = h.preloadReady;
            var m = h;
            t.default = m
        },
        8329: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                __N_SSG: function() {
                    return v
                },
                default: function() {
                    return w
                }
            });
            var r = n(1799);

            function a(e, t) {
                if (null == e) return {};
                var n, r, a = function(e, t) {
                    if (null == e) return {};
                    var n, r, a = {},
                        u = Object.keys(e);
                    for (r = 0; r < u.length; r++) n = u[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
                    return a
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var u = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < u.length; r++) n = u[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (a[n] = e[n])
                }
                return a
            }
            var u = n(5944),
                o = n(5152),
                i = n.n(o),
                l = i()((function() {
                    return Promise.all([n.e(14), n.e(729), n.e(621)]).then(n.bind(n, 7621))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [7621]
                        }
                    },
                    ssr: !1
                }),
                s = i()((function() {
                    return Promise.all([n.e(14), n.e(729), n.e(748)]).then(n.bind(n, 4748))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [4748]
                        }
                    },
                    ssr: !1
                }),
                d = i()((function() {
                    return Promise.all([n.e(14), n.e(368), n.e(386)]).then(n.bind(n, 4386))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [4386]
                        }
                    },
                    ssr: !1
                }),
                f = i()((function() {
                    return Promise.all([n.e(14), n.e(368), n.e(675), n.e(768)]).then(n.bind(n, 7780))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [7780]
                        }
                    },
                    ssr: !1
                }),
                c = i()((function() {
                    return Promise.all([n.e(14), n.e(368), n.e(336)]).then(n.bind(n, 9336))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [9336]
                        }
                    },
                    ssr: !1
                }),
                b = i()((function() {
                    return Promise.all([n.e(14), n.e(368), n.e(66), n.e(310)]).then(n.bind(n, 7310))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [7310]
                        }
                    },
                    ssr: !1
                }),
                p = i()((function() {
                    return Promise.all([n.e(14), n.e(729), n.e(66), n.e(607)]).then(n.bind(n, 3607))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [3607]
                        }
                    },
                    ssr: !1
                }),
                _ = i()((function() {
                    return Promise.all([n.e(14), n.e(34)]).then(n.bind(n, 8034))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [8034]
                        }
                    },
                    ssr: !1
                }),
                h = i()((function() {
                    return Promise.all([n.e(14), n.e(348)]).then(n.bind(n, 8348))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [8348]
                        }
                    },
                    ssr: !1
                }),
                y = i()((function() {
                    return Promise.all([n.e(14), n.e(729), n.e(66), n.e(249)]).then(n.bind(n, 7249))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [7249]
                        }
                    },
                    ssr: !1
                }),
                m = {
                    login: _,
                    loginBio: h,
                    tarif: i()((function() {
                        return Promise.all([n.e(14), n.e(729), n.e(140)]).then(n.bind(n, 8140))
                    }), {
                        loadableGenerated: {
                            webpack: function() {
                                return [8140]
                            }
                        },
                        ssr: !1
                    }),
                    home: l,
                    homeSidikJari: s,
                    newtarif: y,
                    identity: d,
                    newHome: f,
                    tokenBifast: s,
                    identity2: c,
                    bifast: p,
                    tarifPhone: b
                },
                v = !0,
                w = function(e) {
                    var t = e.pageType,
                        n = a(e, ["pageType"]),
                        o = m[t];
                    return o ? (0, u.tZ)(o, (0, r.Z)({}, n)) : null
                }
        },
        5152: function(e, t, n) {
            e.exports = n(638)
        }
    },
    function(e) {
        e.O(0, [774, 888, 179], (function() {
            return t = 522, e(e.s = t);
            var t
        }));
        var t = e.O();
        _N_E = t
    }
]);