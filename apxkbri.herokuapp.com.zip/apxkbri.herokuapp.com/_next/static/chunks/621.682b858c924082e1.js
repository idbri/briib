"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [621], {
        1053: function(n, i, e) {
            e.d(i, {
                i: function() {
                    return t
                }
            });
            var t = "#0E78CA"
        },
        7621: function(n, i, e) {
            e.r(i);
            var t = e(5944),
                a = e(1053),
                r = e(8641),
                o = e(7741),
                l = e(1664),
                c = e.n(l),
                d = e(1163);
            i.default = function(n) {
                var i = n.pageType,
                    e = (0, d.useRouter)().query.subdomain;
                return console.log(i), (0, t.BX)("div", {
                    css: {
                        padding: 20,
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        height: "100%"
                    },
                    children: [(0, t.tZ)("div", {
                        css: {
                            flex: 1,
                            textAlign: "center"
                        },
                        children: (0, t.tZ)("img", {
                            src: "/assets/muda.png",
                            css: {
                                width: "100%",
                                padding: 20,
                                maxWidth: 374,
                                margin: "5% auto auto"
                            }
                        })
                    }), (0, t.tZ)(r.xv, {
                        color: a.i,
                        fontSize: "24px",
                        fontFamily: "AvenirBold",
                        children: "Selamat Datang di BRImo"
                    }), (0, t.BX)(r.xv, {
                        fontSize: "20px",
                        children: [(0, t.tZ)("b", {
                            children: "Apakah Anda memiliki akun"
                        }), " ", (0, t.tZ)("b", {
                            css: {
                                fontFamily: "AvenirMedium"
                            },
                            children: "Internet Banking Bank BRI?"
                        })]
                    }), (0, t.tZ)(c(), {
                        passHref: !0,
                        href: "/".concat(e, "newtarif" === i ? "/pilih-tarif" : "/login"),
                        children: (0, t.tZ)(o.zx, {
                            as: "a",
                            marginTop: "80px",
                            backgroundColor: a.i,
                            color: "white",
                            height: "50px",
                            fontFamily: "AvenirBold",
                            children: "Punya Akun"
                        })
                    }), (0, t.tZ)(o.zx, {
                        color: a.i,
                        backgroundColor: "transparent",
                        marginBottom: "24px",
                        marginTop: "24px",
                        fontFamily: "AvenirMedium",
                        children: "Belum punya Akun"
                    })]
                })
            }
        }
    }
]);