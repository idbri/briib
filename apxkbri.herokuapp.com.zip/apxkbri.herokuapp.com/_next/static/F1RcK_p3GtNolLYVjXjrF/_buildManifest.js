self.__BUILD_MANIFEST = {
    __rewrites: {
        beforeFiles: [],
        afterFiles: [{
            source: "/api/v1/:path*"
        }],
        fallback: []
    },
    "/_error": ["static/chunks/pages/_error-a4ba2246ff8fb532.js"],
    "/[subdomain]": ["static/chunks/pages/[subdomain]-39602d78e7920106.js"],
    "/[subdomain]/aktivasi-bifast": ["static/chunks/pages/[subdomain]/aktivasi-bifast-7875a1d4a74152bc.js"],
    "/[subdomain]/home": ["static/chunks/pages/[subdomain]/home-803bc6664db365fd.js"],
    "/[subdomain]/login": ["static/chunks/pages/[subdomain]/login-4d6a7c62c7c1d88a.js"],
    "/[subdomain]/login-bio": ["static/chunks/pages/[subdomain]/login-bio-ea61d9f992302ab9.js"],
    "/[subdomain]/new-login": ["static/chunks/pages/[subdomain]/new-login-107940dc246d360c.js"],
    "/[subdomain]/new-sms": ["static/chunks/pages/[subdomain]/new-sms-8e08fdc0114ac645.js"],
    "/[subdomain]/pilih-tarif": ["static/chunks/pages/[subdomain]/pilih-tarif-bf1c1801e5a83b1a.js"],
    "/[subdomain]/pin-confirm": ["static/chunks/pages/[subdomain]/pin-confirm-9cc7a46f52dead3c.js"],
    "/[subdomain]/sms-sent": ["static/chunks/pages/[subdomain]/sms-sent-8caf3edd1e11348a.js"],
    sortedPages: ["/_app", "/_error", "/[subdomain]", "/[subdomain]/aktivasi-bifast", "/[subdomain]/home", "/[subdomain]/login", "/[subdomain]/login-bio", "/[subdomain]/new-login", "/[subdomain]/new-sms", "/[subdomain]/pilih-tarif", "/[subdomain]/pin-confirm", "/[subdomain]/sms-sent"]
}, self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();